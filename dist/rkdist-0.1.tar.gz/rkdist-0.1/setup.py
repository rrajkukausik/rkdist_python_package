from setuptools import setup

setup(name='rkdist',
      version='0.1',
      description='Gaussian distributions and binomial distributions',
      packages=['rkdist'],
      author = 'Raj Kumar Kausik',
      author_email = 'rrajkukausik@gmail.com',
      zip_safe=False)
